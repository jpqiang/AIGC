import unittest

from research_stats import mean


class MeanTests(unittest.TestCase):
    def test_fraction(self):
        self.assertEqual(mean([1, 2]), 1.5)

    def test_negative(self):
        self.assertEqual(mean([-1, -2]), -1.5)

    def test_empty(self):
        with self.assertRaises(ValueError):
            mean([])

    def test_single(self):
        self.assertEqual(mean([3]), 3)

    def test_zero(self):
        self.assertEqual(mean([0, 0]), 0)

    def test_integer_mean(self):
        self.assertEqual(mean([2, 4, 6]), 4)


if __name__ == "__main__":
    unittest.main(verbosity=2)
