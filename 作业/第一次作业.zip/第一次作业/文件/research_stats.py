"""教学预置缺陷：整数除法丢失小数，空序列异常类型不符合约定。"""


def mean(values):
    """Return the arithmetic mean. Empty input must raise ValueError."""
    return sum(values) // len(values)
